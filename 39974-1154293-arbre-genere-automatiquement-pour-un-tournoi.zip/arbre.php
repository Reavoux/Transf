<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Arbre test</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" class="Style1">
</head>
<body>

<?
/***********************************************/
/*         Si nb_equipe declarer               */
/***********************************************/

if(isset($_GET['nb_equipe']))
{

/***********************************************/
/*        Les vars globales                    */
/***********************************************/

$nb_equipe = $_GET['nb_equipe'];

$nb_col = 1;
$nb_col_p = 1;
$deb_col = 0;
$esp_col = 0;
$is_case = 1;

/***********************************************/
/*            Les vars de style                */
/***********************************************/
$height = 15;
$width = 80;

/***********************************************/
/*          Calculs globaux                    */
/***********************************************/
$max_col = 0;
	for($i = 0 ; pow(2 , $i) <= $nb_equipe ; $i++) $max_col += 2;
	$max_col--;
$nb_ligne = (($nb_equipe-1) *4) + 2;

/* On Commence la table (pour les colonnes) */
echo "<table cellpadding='0' cellspacing='0'><tr>";

/* On fait une boucle jusqu'au nombre maximum de colonne */
for($nb_col ; $nb_col <= $max_col ; $nb_col++)
{



	/* On reinitilise quelques variable et on affiche une nouvelle colonne */
	echo "<td valign='top' width='".$width."'>";
	$is_case = 1;
	
/* Si la colonne n'est pas une colonne lien */	
if($nb_col % 2 == 1)
{
	/* Certain calcul */
	$deb_col = pow(2 , $nb_col_p) - 1;
	$esp_col = $deb_col * 2;
	
	/* Une boucle du nombre de ligne dans une colonne */
  for($i = 1;$i < $nb_ligne ; $i++)
	{
	  /* Si on a pas atteint le premier affichage */
		if($i < $deb_col)
		{	
			echo "<table cellpadding='0' cellspacing='0' border='0' height='".$height."'><tr><td></td></tr></table>";
		}
		
		/* si c'est une case ( de hauteur 2 * $height ) et que c'est bien la premiere ligne de la case (grace au modulo) */
		else if($is_case == 1 && $i % 2 == 1)
		{
			/* Le texte d'affichage de la case */
			echo "<table cellpadding='0' cellspacing='0' border='1' height='".(2*$height)."' bgcolor='#8080FF' width='".$width."' align='center'><tr><td width='".$width."' align='center'><font size='1'>".$i."</font></td></tr></table>";
			$i += 2;
			$is_case = 0;
		}
		/*Sinon :) 
		else
		{
			echo "<table cellpadding='0' cellspacing='0' border='0' height='".$height."'><tr><td></td></tr></table>";
		}*/
		/*rapiditer on saute directement les espaces vides et on declare qu'il va y avoir de nouveau une case */
		if($is_case == 0 && $i % 2 == 1)
		{
			echo "<table cellpadding='0' cellspacing='0' border='0' height='".($esp_col)*$height."'><tr><td></td></tr></table>";
			$i += $esp_col -1;
			$is_case = 1;
		}
	  
	}
	
	
}

/*************************************************/
/*          Si c'est une colonne lien            */
/*            Le plus chiant                     */
/*************************************************/
else if($nb_col % 2 == 0)
{
  /* On change quelques variables */
	$nb_col_pair = $nb_col;
	
	$deb_col = pow(2 , $nb_col_p);
	$nb_col_p++;
	$esp_col = $deb_col * 2;
	
	/* Meme boucle que tout  l'heure boucle dunombre de ligne */
	for($i = 1 ; $i < $nb_ligne ; $i++)
	{
	  /* Pareil : si aucun affichage encore */
		if($i < $deb_col)
		{	
			echo "<table cellpadding='0' cellspacing='0' border='0' height='".$height."'><tr><td></td></tr></table>";
		}
		
		/* Si on doit afficher les liens */
		else if($is_case == 1 && $i % 2 == 0)
		{
			echo "<table cellpadding='0' cellspacing='0' border='0' height='".$esp_col*$height."'>";
			
			/* Je fonctionne comme �a , on fait une boucle du nombre de ligne cons�cutive pour un lien */
			for ($i2 = 1 ; $i2 <= $esp_col ; $i2++)
			{
			  /* Si premiere ligne */
				if($i2 == 1)
				{
					echo "<tr><td width='".($width)."' height='".$height."' valign='top'>
									<table cellpadding='0' cellspacing='0' border='0'><tr><td height='".$height."' valign='top' width='".($width/2 - 2)."'>
															<table cellpadding='0' cellspacing='0' border='0'><tr height='4'><td bgcolor='#000000' width='".($width/2 - 2)."'></td></tr>
															<tr height='".($height-4)."'><td bgcolor='#FFFFFF'></td></tr></table></td>
									<td width='4' height='".$height."' bgcolor='#000000'></td>
									<td height='".$height."' bgcolor='#FFFFFF' width='".($width/2 - 2)."'></td></tr></table></td></tr>";
				}
				/* Si ligne du milieu */
				else if($i2 == ($esp_col)/2 )
				{
					echo "<tr><td width='".($width)."' height='".$height."'>
									<table cellpadding='0' cellspacing='0' border='0'><tr><td height='".$height."' bgcolor='#FFFFFF' width='".($width/2 - 2)."'></td>
									<td bgcolor='#000000' width='4' height='".$height."'></td>
									<td height='".$height."' width='".($width/2 - 2)."'>
															<table cellpadding='0' cellspacing='0' border='0'>
															<tr height='".(($height/2) +2 )."'><td bgcolor='#FFFFFF'></td></tr>
															<tr height='4'><td bgcolor='#000000' width='".($width/2 - 2)."'></td></tr>
															<tr height='".(($height/2)-6)."'><td bgcolor='#FFFFFF'></td></tr>
															</table></td></tr></table></td></tr>";
				}
				/* Si derniere ligne */
				else if($i2 == ($esp_col))
				{
					echo "<tr><td width='".($width)."' height='".$height."' valign='bottom'>
									<table cellpadding='0' cellspacing='0' border='0'><tr><td height='".$height."' valign='bottom' width='".($width/2 - 2)."'>
															<table cellpadding='0' cellspacing='0' border='0'><tr height='".($height-4)."'><td bgcolor='#FFFFFF'></td></tr>
															<tr height='4'><td bgcolor='#000000' width='".($width/2 - 2)."'></td></tr></table></td>
									<td width='4' bgcolor='#000000' height='".$height."'></td>
									<td height='".$height."' bgcolor='#FFFFFF' width='".($width/2 - 2)."'></td></tr></table></td></tr>";
					$is_case = 0;
				}
				/* Si ligne verticale */
				else
				{
					echo "<tr><td width='".($width)."' height='".$height."' valign='top'>
									<table cellpadding='0' cellspacing='0' border='0'><tr><td bgcolor='#FFFFFF' width='".($width/2 - 2)."' height='".$height."'></td>
									<td width='4' bgcolor='#000000' height='".$height."'></td>
									<td bgcolor='#FFFFFF' height='".$height."' width='".($width/2 - 2)."'></td></tr></table></td></tr>";
				}
			}		 
			/* on incr�mente le nobre de ligne du nombre de ligne cons�cutive pour un lien */
			$i += $esp_col;
			
		}
		
		/* Sinon 
		else
		{
			echo "<table cellpadding='0' cellspacing='0' border='0' height='".$height."'><tr><td></td></tr></table>";
		}*/
		
		/*Si on doit afficher des espaces , on les affiche avant d'�ecuter une nouvelle fois la boucle , pour a rapiditer */
		if($is_case == 0 && $i % 2 == 0)
		{
			echo "<table cellpadding='0' cellspacing='0' border='0' height='".$esp_col*$height."'><tr><td></td></tr></table>";
			$i += $esp_col - 1;
			$is_case = 1;
	  }
	}
}

/* On ferme la colonne */
echo "</td>";

/*Fin de la premiere boucle */
}

/*On ferme la table */
echo "</tr></table>";


}

/*******************************************/
/*Si on a pas renseigner le nombre d'�quipe*/
/*******************************************/

else
{
	?>
	<form action="#" method="get" name="nb_equipe">
	Nombre d'�quipe ? <input type="text" name="nb_equipe" value="4">
	<input type="submit" name="OK">
	</form>
	<?
}
?>
</body>
</html>
