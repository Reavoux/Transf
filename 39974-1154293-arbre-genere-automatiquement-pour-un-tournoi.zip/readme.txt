Arbre g�n�r� automatiquement pour un tournoi--------------------------------------------
Url     : http://codes-sources.commentcamarche.net/source/39974-arbre-genere-automatiquement-pour-un-tournoiAuteur  : knasucreDate    : 05/08/2013
Licence :
=========

Ce document intitul� � Arbre g�n�r� automatiquement pour un tournoi � issu de CommentCaMarche
(codes-sources.commentcamarche.net) est mis � disposition sous les termes de
la licence Creative Commons. Vous pouvez copier, modifier des copies de cette
source, dans les conditions fix�es par la licence, tant que cette note
appara�t clairement.

Description :
=============

Bonjour a tous ,
<br />
<br />Voici mon premier code sur phpcs ,ce code est un
e partie du site que je suis en train de r&eacute;alis&eacute; , il permet de g&
eacute;n&eacute;r&eacute; un arbre dynamiquement en fonction du nombre de partic
ipant voulu , c'est la version 1 , je compte impl&eacute;ment&eacute; une gestio
n des poules , et accelerer egalement la rapiditer car pour un grand nombre de j
oueur , le code est assez long &agrave; s'&eacute;xecuter.
<br /><a name='sourc
e-exemple'></a><h2> Source / Exemple : </h2>
<br /><pre class='code' data-mode
='basic'>
&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.01 Transitional//EN
&quot; &quot;<a href='http://www.w3.org/TR/html4/loose.dtd' target='_blank'>http
://www.w3.org/TR/html4/loose.dtd</a>&quot;&gt;
&lt;html&gt;
&lt;head&gt;
&lt;
title&gt;Arbre test&lt;/title&gt;
&lt;meta http-equiv=&quot;Content-Type&quot; 
content=&quot;text/html; charset=iso-8859-1&quot; class=&quot;Style1&quot;&gt;

&lt;/head&gt;
&lt;body&gt;

&lt;?
/*****************************************
******/
/*         Si nb_equipe declarer               */
/*******************
****************************/

if(isset($_GET['nb_equipe']))
{

/**********
*************************************/
/*        Les vars globales             
       */
/***********************************************/

$nb_equipe = $_G
ET['nb_equipe'];

$nb_col = 1;
$nb_col_p = 1;
$deb_col = 0;
$esp_col = 0;

$is_case = 1;

/***********************************************/
/*          
  Les vars de style                */
/****************************************
*******/
$height = 15;
$width = 80;

/**************************************
*********/
/*          Calculs globaux                    */
/****************
*******************************/
$max_col = 0;
	for($i = 0 ; pow(2 , $i) &lt;=
 $nb_equipe ; $i++) $max_col += 2;
	$max_col--;
$nb_ligne = (($nb_equipe-1) *4
) + 2;

/* On Commence la table (pour les colonnes) */
echo &quot;&lt;table c
ellpadding='0' cellspacing='0'&gt;&lt;tr&gt;&quot;;

/* On fait une boucle jus
qu'au nombre maximum de colonne */
for($nb_col ; $nb_col &lt;= $max_col ; $nb_c
ol++)
{

	/* On reinitilise quelques variable et on affiche une nouvelle colo
nne */
	echo &quot;&lt;td valign='top' width='&quot;.$width.&quot;'&gt;&quot;;

	$is_case = 1;
	
/* Si la colonne n'est pas une colonne lien */	
if($nb_col 
% 2 == 1)
{
	/* Certain calcul */
	$deb_col = pow(2 , $nb_col_p) - 1;
	$esp_
col = $deb_col * 2;
	
	/* Une boucle du nombre de ligne dans une colonne */
 
 for($i = 1;$i &lt; $nb_ligne ; $i++)
	{
	  /* Si on a pas atteint le premier 
affichage */
		if($i &lt; $deb_col)
		{	
			echo &quot;&lt;table cellpadding=
'0' cellspacing='0' border='0' height='&quot;.$height.&quot;'&gt;&lt;tr&gt;&lt;t
d&gt;&lt;/td&gt;&lt;/tr&gt;&lt;/table&gt;&quot;;
		}
		
		/* si c'est une cas
e ( de hauteur 2 * $height ) et que c'est bien la premiere ligne de la case (gra
ce au modulo) */
		else if($is_case == 1 &amp;&amp; $i % 2 == 1)
		{
			/* Le
 texte d'affichage de la case */
			echo &quot;&lt;table cellpadding='0' cellsp
acing='0' border='1' height='&quot;.(2*$height).&quot;' bgcolor='#8080FF' width=
'&quot;.$width.&quot;' align='center'&gt;&lt;tr&gt;&lt;td width='&quot;.$width.&
quot;' align='center'&gt;&lt;font size='1'&gt;&quot;.$i.&quot;&lt;/font&gt;&lt;/
td&gt;&lt;/tr&gt;&lt;/table&gt;&quot;;
			$i += 2;
			$is_case = 0;
		}
		/*
Sinon :) 
		else
		{
			echo &quot;&lt;table cellpadding='0' cellspacing='0' 
border='0' height='&quot;.$height.&quot;'&gt;&lt;tr&gt;&lt;td&gt;&lt;/td&gt;&lt;
/tr&gt;&lt;/table&gt;&quot;;
		}*/
		/*rapiditer on saute directement les espa
ces vides et on declare qu'il va y avoir de nouveau une case */
		if($is_case =
= 0 &amp;&amp; $i % 2 == 1)
		{
			echo &quot;&lt;table cellpadding='0' cellsp
acing='0' border='0' height='&quot;.($esp_col)*$height.&quot;'&gt;&lt;tr&gt;&lt;
td&gt;&lt;/td&gt;&lt;/tr&gt;&lt;/table&gt;&quot;;
			$i += $esp_col -1;
			$is
_case = 1;
		}
	  
	}
	
	
}

/******************************************
*******/
/*          Si c'est une colonne lien            */
/*            Le 
plus chiant                     */
/*******************************************
******/
else if($nb_col % 2 == 0)
{
  /* On change quelques variables */
	$n
b_col_pair = $nb_col;
	
	$deb_col = pow(2 , $nb_col_p);
	$nb_col_p++;
	$esp_
col = $deb_col * 2;
	
	/* Meme boucle que tout  l'heure boucle dunombre de lig
ne */
	for($i = 1 ; $i &lt; $nb_ligne ; $i++)
	{
	  /* Pareil : si aucun affi
chage encore */
		if($i &lt; $deb_col)
		{	
			echo &quot;&lt;table cellpaddi
ng='0' cellspacing='0' border='0' height='&quot;.$height.&quot;'&gt;&lt;tr&gt;&l
t;td&gt;&lt;/td&gt;&lt;/tr&gt;&lt;/table&gt;&quot;;
		}
		
		/* Si on doit af
ficher les liens */
		else if($is_case == 1 &amp;&amp; $i % 2 == 0)
		{
			ec
ho &quot;&lt;table cellpadding='0' cellspacing='0' border='0' height='&quot;.$es
p_col*$height.&quot;'&gt;&quot;;
			
			/* Je fonctionne comme �a , on fait un
e boucle du nombre de ligne cons�cutive pour un lien */
			for ($i2 = 1 ; $i2 &
lt;= $esp_col ; $i2++)
			{
			  /* Si premiere ligne */
				if($i2 == 1)
		
		{
					echo &quot;&lt;tr&gt;&lt;td width='&quot;.($width).&quot;' height='&qu
ot;.$height.&quot;' valign='top'&gt;
									&lt;table cellpadding='0' cellspa
cing='0' border='0'&gt;&lt;tr&gt;&lt;td height='&quot;.$height.&quot;' valign='t
op' width='&quot;.($width/2 - 2).&quot;'&gt;
															&lt;table cellpaddi
ng='0' cellspacing='0' border='0'&gt;&lt;tr height='4'&gt;&lt;td bgcolor='#00000
0' width='&quot;.($width/2 - 2).&quot;'&gt;&lt;/td&gt;&lt;/tr&gt;
													
		&lt;tr height='&quot;.($height-4).&quot;'&gt;&lt;td bgcolor='#FFFFFF'&gt;&lt;/
td&gt;&lt;/tr&gt;&lt;/table&gt;&lt;/td&gt;
									&lt;td width='4' height='&q
uot;.$height.&quot;' bgcolor='#000000'&gt;&lt;/td&gt;
									&lt;td height='&
quot;.$height.&quot;' bgcolor='#FFFFFF' width='&quot;.($width/2 - 2).&quot;'&gt;
&lt;/td&gt;&lt;/tr&gt;&lt;/table&gt;&lt;/td&gt;&lt;/tr&gt;&quot;;
				}
				/*
 Si ligne du milieu */
				else if($i2 == ($esp_col)/2 )
				{
					echo &quo
t;&lt;tr&gt;&lt;td width='&quot;.($width).&quot;' height='&quot;.$height.&quot;'
&gt;
									&lt;table cellpadding='0' cellspacing='0' border='0'&gt;&lt;tr&gt
;&lt;td height='&quot;.$height.&quot;' bgcolor='#FFFFFF' width='&quot;.($width/2
 - 2).&quot;'&gt;&lt;/td&gt;
									&lt;td bgcolor='#000000' width='4' height
='&quot;.$height.&quot;'&gt;&lt;/td&gt;
									&lt;td height='&quot;.$height.
&quot;' width='&quot;.($width/2 - 2).&quot;'&gt;
															&lt;table cellp
adding='0' cellspacing='0' border='0'&gt;
															&lt;tr height='&quot;.
(($height/2) +2 ).&quot;'&gt;&lt;td bgcolor='#FFFFFF'&gt;&lt;/td&gt;&lt;/tr&gt;

															&lt;tr height='4'&gt;&lt;td bgcolor='#000000' width='&quot;.($wi
dth/2 - 2).&quot;'&gt;&lt;/td&gt;&lt;/tr&gt;
															&lt;tr height='&quo
t;.(($height/2)-6).&quot;'&gt;&lt;td bgcolor='#FFFFFF'&gt;&lt;/td&gt;&lt;/tr&gt;

															&lt;/table&gt;&lt;/td&gt;&lt;/tr&gt;&lt;/table&gt;&lt;/td&gt;&l
t;/tr&gt;&quot;;
				}
				/* Si derniere ligne */
				else if($i2 == ($esp_c
ol))
				{
					echo &quot;&lt;tr&gt;&lt;td width='&quot;.($width).&quot;' hei
ght='&quot;.$height.&quot;' valign='bottom'&gt;
									&lt;table cellpadding=
'0' cellspacing='0' border='0'&gt;&lt;tr&gt;&lt;td height='&quot;.$height.&quot;
' valign='bottom' width='&quot;.($width/2 - 2).&quot;'&gt;
															&lt;t
able cellpadding='0' cellspacing='0' border='0'&gt;&lt;tr height='&quot;.($heigh
t-4).&quot;'&gt;&lt;td bgcolor='#FFFFFF'&gt;&lt;/td&gt;&lt;/tr&gt;
												
			&lt;tr height='4'&gt;&lt;td bgcolor='#000000' width='&quot;.($width/2 - 2).&q
uot;'&gt;&lt;/td&gt;&lt;/tr&gt;&lt;/table&gt;&lt;/td&gt;
									&lt;td width=
'4' bgcolor='#000000' height='&quot;.$height.&quot;'&gt;&lt;/td&gt;
									&l
t;td height='&quot;.$height.&quot;' bgcolor='#FFFFFF' width='&quot;.($width/2 - 
2).&quot;'&gt;&lt;/td&gt;&lt;/tr&gt;&lt;/table&gt;&lt;/td&gt;&lt;/tr&gt;&quot;;

					$is_case = 0;
				}
				/* Si ligne verticale */
				else
				{
					
echo &quot;&lt;tr&gt;&lt;td width='&quot;.($width).&quot;' height='&quot;.$heigh
t.&quot;' valign='top'&gt;
									&lt;table cellpadding='0' cellspacing='0' b
order='0'&gt;&lt;tr&gt;&lt;td bgcolor='#FFFFFF' width='&quot;.($width/2 - 2).&qu
ot;' height='&quot;.$height.&quot;'&gt;&lt;/td&gt;
									&lt;td width='4' bg
color='#000000' height='&quot;.$height.&quot;'&gt;&lt;/td&gt;
									&lt;td b
gcolor='#FFFFFF' height='&quot;.$height.&quot;' width='&quot;.($width/2 - 2).&qu
ot;'&gt;&lt;/td&gt;&lt;/tr&gt;&lt;/table&gt;&lt;/td&gt;&lt;/tr&gt;&quot;;
				}

			}		 
			/* on incr�mente le nobre de ligne du nombre de ligne cons�cutive 
pour un lien */
			$i += $esp_col;
			
		}
		
		/* Sinon 
		else
		{
			
echo &quot;&lt;table cellpadding='0' cellspacing='0' border='0' height='&quot;.$
height.&quot;'&gt;&lt;tr&gt;&lt;td&gt;&lt;/td&gt;&lt;/tr&gt;&lt;/table&gt;&quot;
;
		}*/
		
		/*Si on doit afficher des espaces , on les affiche avant d'�ecut
er une nouvelle fois la boucle , pour a rapiditer */
		if($is_case == 0 &amp;&a
mp; $i % 2 == 0)
		{
			echo &quot;&lt;table cellpadding='0' cellspacing='0' b
order='0' height='&quot;.$esp_col*$height.&quot;'&gt;&lt;tr&gt;&lt;td&gt;&lt;/td
&gt;&lt;/tr&gt;&lt;/table&gt;&quot;;
			$i += $esp_col - 1;
			$is_case = 1;

	  }
	}
}

/* On ferme la colonne */
echo &quot;&lt;/td&gt;&quot;;

/*Fin
 de la premiere boucle */
}

/*On ferme la table */
echo &quot;&lt;/tr&gt;&l
t;/table&gt;&quot;;

}

/*******************************************/
/*Si 
on a pas renseigner le nombre d'�quipe*/
/*************************************
******/

else
{
	?&gt;
	&lt;form action=&quot;#&quot; method=&quot;get&quot
; name=&quot;nb_equipe&quot;&gt;
	Nombre d'�quipe ? &lt;input type=&quot;text&q
uot; name=&quot;nb_equipe&quot; value=&quot;4&quot;&gt;
	&lt;input type=&quot;s
ubmit&quot; name=&quot;OK&quot;&gt;
	&lt;/form&gt;
	&lt;?
}
?&gt;
&lt;/body
&gt;
&lt;/html&gt;
</pre>
<br /><a name='conclusion'></a><h2> Conclusion : </
h2>
<br />Bugs connu :
<br />   - Plein de ligne inutile ce rajoute en bas de
 la page , si quelqu'un trouve plus rapidement que moi la solution , qu'il le di
se.
<br />
<br />Si vous avez des am&eacute;lioration suppl&eacute;mentaire a 
me sugg&eacute;r&eacute; , je suis toujours a votre &eacute;coute.
<br />
<br 
/>La capture d'&eacute;cran arrive :)
